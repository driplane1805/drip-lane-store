require("dotenv").config();
const express = require("express");
const session = require("express-session");
const helmet = require("helmet");
const bcrypt = require("bcryptjs");
const Database = require("better-sqlite3");
const crypto = require("crypto");
const path = require("path");

const app = express();
const dbPath = process.env.DATABASE_PATH || (process.env.RENDER ? "/var/data/drip-lane.sqlite" : "drip-lane.sqlite");
const db = new Database(dbPath);
const PORT = process.env.PORT || 3000;
const BASE_URL = process.env.BASE_URL || `http://localhost:${PORT}`;
const COMMISSION = Number(process.env.AFFILIATE_COMMISSION_PERCENT || 10);

db.pragma("journal_mode = WAL");
db.exec(`
CREATE TABLE IF NOT EXISTS users (
 id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, email TEXT UNIQUE NOT NULL,
 password_hash TEXT NOT NULL, role TEXT NOT NULL DEFAULT 'affiliate',
 referral_code TEXT UNIQUE, created_at TEXT DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS products (
 id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, category TEXT NOT NULL,
 price INTEGER NOT NULL, image TEXT NOT NULL, description TEXT DEFAULT '',
 active INTEGER DEFAULT 1
);
CREATE TABLE IF NOT EXISTS orders (
 id INTEGER PRIMARY KEY AUTOINCREMENT, reference TEXT UNIQUE NOT NULL, customer_name TEXT NOT NULL,
 email TEXT NOT NULL, phone TEXT NOT NULL, items_json TEXT NOT NULL, total INTEGER NOT NULL,
 affiliate_id INTEGER, status TEXT DEFAULT 'pending', created_at TEXT DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS commissions (
 id INTEGER PRIMARY KEY AUTOINCREMENT, affiliate_id INTEGER NOT NULL, order_id INTEGER NOT NULL,
 amount INTEGER NOT NULL, status TEXT DEFAULT 'pending', created_at TEXT DEFAULT CURRENT_TIMESTAMP,
 UNIQUE(affiliate_id, order_id)
);
`);

const count = db.prepare("SELECT COUNT(*) n FROM products").get().n;
if (!count) {
  const seed = db.prepare("INSERT INTO products (name,category,price,image,description) VALUES (?,?,?,?,?)");
  [
    ["Everyday Baggy Jean", "Jeans", 24000, "https://images.unsplash.com/photo-1541099649105-f69ad21f3246?w=900", "Relaxed denim for everyday styling. Confirm available sizes before payment."],
    ["Classic Straight Jean", "Jeans", 22000, "https://images.unsplash.com/photo-1541099649105-f69ad21f3246?w=900", "A wardrobe staple you can dress up or down. Confirm available sizes before payment."],
    ["Weekend Jorts", "Jorts", 14000, "https://images.unsplash.com/photo-1541099649105-f69ad21f3246?w=900", "Easy denim shorts for sunny days. Confirm available sizes before payment."],
    ["Everyday Basic Top", "Tops", 6500, "https://images.unsplash.com/photo-1551163943-3f6a855d1153?w=900", "A cute basic to style with your favourite denim."],
    ["Girl's Night Top", "Tops", 8500, "https://images.unsplash.com/photo-1551163943-3f6a855d1153?w=900", "A going-out top for dinner dates and nights out."],
    ["Classic Corporate Shirt", "Corporate Shirts", 7500, "https://images.unsplash.com/photo-1598554747436-c9293d6a588f?w=900", "A polished shirt for work, class and smart-casual looks."]
    ].forEach(p => seed.run(...p));
}

app.use(helmet({ contentSecurityPolicy: false }));
// Paystack webhook must receive the untouched raw request body for signature verification.
app.post("/api/paystack/webhook", express.raw({ type: "application/json" }), (req, res) => {
  const secret = process.env.PAYSTACK_SECRET_KEY || "";
  const signature = req.headers["x-paystack-signature"];
  const expected = crypto.createHmac("sha512", secret).update(req.body).digest("hex");
  if (!signature || !crypto.timingSafeEqual(Buffer.from(signature), Buffer.from(expected))) return res.sendStatus(401);
  const event = JSON.parse(req.body.toString());
  if (event.event === "charge.success") {
    const reference = event.data.reference;
    const order = db.prepare("SELECT * FROM orders WHERE reference=?").get(reference);
    if (order && Number(event.data.amount) === order.total * 100) {
      db.prepare("UPDATE orders SET status='paid' WHERE id=?").run(order.id);
      if (order.affiliate_id) {
        const amount = Math.round(order.total * COMMISSION / 100);
        db.prepare("INSERT OR IGNORE INTO commissions (affiliate_id,order_id,amount) VALUES (?,?,?)").run(order.affiliate_id, order.id, amount);
      }
    }
  }
  res.sendStatus(200);
});

app.use(express.json({ limit: "100kb" }));
app.use(express.urlencoded({ extended: false }));
app.use(session({
  secret: process.env.SESSION_SECRET || (process.env.NODE_ENV === "production" ? (() => { throw new Error("SESSION_SECRET must be set in production."); })() : "development-only-change-me"),
  resave: false, saveUninitialized: false,
  cookie: { httpOnly: true, sameSite: "lax", secure: process.env.NODE_ENV === "production", maxAge: 7 * 24 * 60 * 60 * 1000 }
}));
app.use(express.static(path.join(__dirname, "public")));

function safeUser(u) {
  return u && { id: u.id, name: u.name, email: u.email, role: u.role, referral_code: u.referral_code };
}
function requireUser(req, res, next) {
  if (!req.session.userId) return res.status(401).json({ error: "Please log in first." });
  req.user = db.prepare("SELECT * FROM users WHERE id=?").get(req.session.userId);
  if (!req.user) return res.status(401).json({ error: "Session expired." });
  next();
}
function requireAdmin(req, res, next) {
  requireUser(req, res, () => {
    if (req.user.role !== "admin") return res.status(403).json({ error: "Admin access only." });
    next();
  });
}
function makeCode(name) {
  const base = (name.replace(/[^a-z0-9]/gi, "").slice(0, 6) || "DRIP").toUpperCase();
  return base + crypto.randomBytes(2).toString("hex").toUpperCase();
}

app.get("/api/products", (req, res) => {
  res.json(db.prepare("SELECT * FROM products WHERE active=1 ORDER BY id DESC").all());
});
app.get("/api/me", (req, res) => {
  const user = req.session.userId ? db.prepare("SELECT * FROM users WHERE id=?").get(req.session.userId) : null;
  res.json({ user: safeUser(user) });
});
app.get("/r/:code", (req, res) => {
  const affiliate = db.prepare("SELECT id FROM users WHERE referral_code=? AND role='affiliate'").get(req.params.code);
  if (affiliate) req.session.affiliateId = affiliate.id;
  res.redirect("/#shop");
});

app.post("/api/register", async (req, res) => {
  const { name, email, password } = req.body || {};
  if (!name || !email || !password || password.length < 8) return res.status(400).json({ error: "Enter your name, a valid email and a password of at least 8 characters." });
  const normalized = String(email).trim().toLowerCase();
  if (db.prepare("SELECT id FROM users WHERE email=?").get(normalized)) return res.status(409).json({ error: "An account with this email already exists." });
  const hash = await bcrypt.hash(password, 12);
  const code = makeCode(name);
  const result = db.prepare("INSERT INTO users (name,email,password_hash,role,referral_code) VALUES (?,?,?,'affiliate',?)").run(name.trim(), normalized, hash, code);
  req.session.userId = result.lastInsertRowid;
  res.json({ user: safeUser(db.prepare("SELECT * FROM users WHERE id=?").get(result.lastInsertRowid)) });
});
app.post("/api/login", async (req, res) => {
  const email = String(req.body.email || "").trim().toLowerCase();
  const user = db.prepare("SELECT * FROM users WHERE email=?").get(email);
  if (!user || !(await bcrypt.compare(req.body.password || "", user.password_hash))) return res.status(401).json({ error: "Email or password is incorrect." });
  req.session.userId = user.id;
  res.json({ user: safeUser(user) });
});
app.post("/api/logout", (req, res) => req.session.destroy(() => res.json({ ok: true })));

app.get("/api/affiliate/dashboard", requireUser, (req, res) => {
  if (req.user.role !== "affiliate") return res.status(403).json({ error: "Affiliate account required." });
  const sales = db.prepare("SELECT COUNT(*) n FROM orders WHERE affiliate_id=? AND status='paid'").get(req.user.id).n;
  const totals = db.prepare("SELECT COALESCE(SUM(amount),0) total FROM commissions WHERE affiliate_id=?").get(req.user.id).total;
  const pending = db.prepare("SELECT COALESCE(SUM(amount),0) total FROM commissions WHERE affiliate_id=? AND status='pending'").get(req.user.id).total;
  const rows = db.prepare(`SELECT c.amount,c.status,c.created_at,o.reference FROM commissions c JOIN orders o ON o.id=c.order_id WHERE c.affiliate_id=? ORDER BY c.id DESC LIMIT 30`).all(req.user.id);
  res.json({ referralUrl: `${BASE_URL}/r/${req.user.referral_code}`, sales, totalCommission: totals, pendingCommission: pending, commissions: rows, rate: COMMISSION });
});

app.post("/api/checkout", async (req, res) => {
  const { name, email, phone, items } = req.body || {};
  if (!name || !email || !phone || !Array.isArray(items) || !items.length) return res.status(400).json({ error: "Please complete your contact details and cart." });
  const clean = [];
  let total = 0;
  for (const item of items) {
    const product = db.prepare("SELECT * FROM products WHERE id=? AND active=1").get(Number(item.id));
    const qty = Math.max(1, Math.min(10, Number(item.qty) || 1));
    if (!product) return res.status(400).json({ error: "One of the products is no longer available." });
    clean.push({ id: product.id, name: product.name, price: product.price, qty });
    total += product.price * qty;
  }
  if (!process.env.PAYSTACK_SECRET_KEY || process.env.PAYSTACK_SECRET_KEY.includes("replace_me")) return res.status(503).json({ error: "Online payment is not configured yet. Add your Paystack secret key in the server environment before accepting payments." });
  const reference = "DL" + Date.now() + crypto.randomBytes(3).toString("hex");
  const affiliateId = req.session.affiliateId || null;
  const result = db.prepare("INSERT INTO orders (reference,customer_name,email,phone,items_json,total,affiliate_id) VALUES (?,?,?,?,?,?,?)")
    .run(reference, name.trim(), email.trim().toLowerCase(), phone.trim(), JSON.stringify(clean), total, affiliateId);
  try {
    const response = await fetch("https://api.paystack.co/transaction/initialize", {
      method: "POST",
      headers: { Authorization: `Bearer ${process.env.PAYSTACK_SECRET_KEY}`, "Content-Type": "application/json" },
      body: JSON.stringify({ email, amount: total * 100, reference, callback_url: `${BASE_URL}/payment-return` })
    });
    const data = await response.json();
    if (!response.ok || !data.status) throw new Error(data.message || "Payment initialization failed.");
    res.json({ authorizationUrl: data.data.authorization_url });
  } catch (e) {
    db.prepare("UPDATE orders SET status='payment_error' WHERE id=?").run(result.lastInsertRowid);
    res.status(502).json({ error: "Could not start payment. Please try again." });
  }
});

app.get("/payment-return", (req, res) => res.sendFile(path.join(__dirname, "public", "index.html")));
app.get("/api/admin/summary", requireAdmin, (req, res) => {
  res.json({
    orders: db.prepare("SELECT COUNT(*) n FROM orders").get().n,
    paidOrders: db.prepare("SELECT COUNT(*) n FROM orders WHERE status='paid'").get().n,
    affiliates: db.prepare("SELECT COUNT(*) n FROM users WHERE role='affiliate'").get().n,
    pendingPayouts: db.prepare("SELECT COALESCE(SUM(amount),0) n FROM commissions WHERE status='pending'").get().n,
    recentOrders: db.prepare("SELECT reference,customer_name,email,total,status,created_at FROM orders ORDER BY id DESC LIMIT 20").all()
  });
});
app.post("/api/admin/products", requireAdmin, (req, res) => {
  const { name, category, price, image, description } = req.body || {};
  if (!name || !category || !Number(price) || !image) return res.status(400).json({ error: "Name, category, price and image URL are required." });
  const r = db.prepare("INSERT INTO products (name,category,price,image,description) VALUES (?,?,?,?,?)").run(name, category, Number(price), image, description || "");
  res.json({ id: r.lastInsertRowid });
});
app.patch("/api/admin/products/:id", requireAdmin, (req, res) => {
  const { active } = req.body || {};
  db.prepare("UPDATE products SET active=? WHERE id=?").run(active ? 1 : 0, Number(req.params.id));
  res.json({ ok: true });
});
app.post("/api/admin/commissions/:id/paid", requireAdmin, (req, res) => {
  db.prepare("UPDATE commissions SET status='paid' WHERE id=?").run(Number(req.params.id));
  res.json({ ok: true });
});

app.get("*", (req, res) => res.sendFile(path.join(__dirname, "public", "index.html")));

async function bootstrapAdmin() {
  const email = process.env.ADMIN_EMAIL;
  const password = process.env.ADMIN_PASSWORD;
  if (email && password && !db.prepare("SELECT id FROM users WHERE email=?").get(email.toLowerCase())) {
    const hash = await bcrypt.hash(password, 12);
    db.prepare("INSERT INTO users (name,email,password_hash,role) VALUES ('DRIP LANE Admin',?,?, 'admin')").run(email.toLowerCase(), hash);
    console.log("Admin account created from environment settings.");
  }
}
bootstrapAdmin().then(() => app.listen(PORT, () => console.log(`DRIP LANE running at ${BASE_URL}`)));
