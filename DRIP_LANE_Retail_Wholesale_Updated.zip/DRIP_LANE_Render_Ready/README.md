# DRIP LANE — Affiliate Fashion Store

A branded storefront starter for DRIP LANE with product collections, shopping bag, affiliate sign-up/login, referral links, commission records, admin endpoints and Paystack checkout integration.

## Important: this is source code, not a live published website
The project has to be deployed to a hosting provider and connected to a production database/payment account before real customers can pay. The included SQLite database is suitable for local testing/small MVP testing; for a production launch, use managed PostgreSQL and a persistent server/volume. Do not accept live orders until payment webhooks and hosting have been tested.

## Run locally
1. Install Node.js 20 or newer.
2. Extract the ZIP and open this folder in a terminal.
3. Run `npm install`.
4. Copy `.env.example` to `.env`.
5. Set a long random `SESSION_SECRET`, your admin email/password, and Paystack test secret key.
6. Run `npm start`.
7. Open `http://localhost:3000`.

The store will display sample products and prices. Replace these with your real product names, prices, sizes, stock and image URLs before launch.

## Paystack setup
- Create/verify your Paystack business account.
- Put the secret key in the server environment as `PAYSTACK_SECRET_KEY` (never put it in browser JavaScript).
- Set the Paystack webhook URL to `https://YOUR-DOMAIN/api/paystack/webhook`.
- Set `BASE_URL` to your live HTTPS domain.
- Test successful, failed, duplicate and refunded payment flows before going live.
- The app uses a server-side HMAC signature check and verifies the amount/reference before recording an affiliate commission.

## Affiliate model
- Default commission is 10%, configurable with `AFFILIATE_COMMISSION_PERCENT`.
- Affiliates register, receive a unique referral URL and can see recorded paid-order commissions.
- The referral is attributed to the visitor's session when they visit `/r/CODE`.
- Commission is recorded only when Paystack sends a verified `charge.success` webhook.
- Admin marks commission as paid after making a payout. This starter does not automatically transfer money to affiliates.

## Admin
The first run creates an admin user from `ADMIN_EMAIL` and `ADMIN_PASSWORD` if that email is not already registered. Log in through the website to see the admin overview.
Protected admin API endpoints:
- `GET /api/admin/summary`
- `POST /api/admin/products` with `{ "name", "category", "price", "image", "description" }`
- `PATCH /api/admin/products/:id` with `{ "active": false }` to hide a product
- `POST /api/admin/commissions/:id/paid` to mark a payout as paid

A production-ready admin product/order management interface, refunds, delivery tracking, size/variant stock control, rate limiting, email receipts, password reset, audit logs, privacy policy and terms still need to be added before public launch.

## Before publishing
- Confirm the legal business name/contact details, customer service WhatsApp, delivery locations, returns/exchange policy and privacy policy.
- Replace all sample images with photos you own or have permission to use.
- Confirm every product price and stock quantity.
- Add a real domain and HTTPS.
- Use managed database backups and secure environment variables.
- Configure rate limiting, CSRF protection, secure persistent sessions, monitoring and admin audit logs.
- Ask a Nigerian lawyer/accountant to review consumer terms, privacy/data protection, tax and affiliate commission terms.


## Render deployment configuration
This folder includes `render.yaml`. In Render, choose **New → Blueprint** after the project is in a GitHub repository and select that repository. The Blueprint provisions a Node web service and a persistent disk for the SQLite database.

When prompted, set:
- `BASE_URL` to the final Render URL, for example `https://your-service.onrender.com`
- `ADMIN_EMAIL` to an email you control
- `ADMIN_PASSWORD` to a unique, long password (do not reuse an email password)
- `PAYSTACK_SECRET_KEY` to your Paystack **test** secret key initially

Do not share secret keys in chat or commit them to GitHub. Test checkout and webhook handling before switching to live Paystack keys. The persistent disk uses Render's paid Starter service; a free ephemeral service is not suitable for keeping SQLite orders and accounts safely between deploys.

This is a deploy-configured starter, not a verified production launch. Product images/prices, customer policies, payment credentials, webhook setup, database backups and end-to-end payment tests still need the owner's review.


## Nigeria storefront setup before taking orders
- The storefront displays all prices in Nigerian naira (₦).
- The initial catalog contains sample products, sample prices and illustrative stock photos. Replace these with your real product photos, exact prices, available sizes and stock before launch.
- Paystack checkout is not active until the owner adds their Paystack secret key in Render and completes a test payment plus webhook verification.
- Do not publish personal bank details in the source code. If you want manual bank transfer, show account details only after deciding exactly how orders will be verified; never mark an order paid based on a customer-uploaded receipt alone.
- Review delivery fees, delivery areas, returns/exchange rules, contact/WhatsApp number, privacy notice and terms before accepting customer orders.
- The included affiliate account features are optional. Test registration, login, referral tracking and commission calculations before advertising the affiliate programme.


## Store contact and bank transfer
The storefront displays the WhatsApp contact and FCMB transfer details supplied by the owner. Customers are instructed to confirm stock, final order total and delivery fee on WhatsApp before transferring. Keep the WhatsApp number active and monitor it for orders. The WhatsApp order button opens a prefilled message; it does not automatically create an order in the store database.

## Retail and wholesale
Retail products are displayed in the shop. Wholesale enquiries use a separate section and WhatsApp message because wholesale prices, minimum quantities and available stock must be confirmed with the owner. Add your current wholesale price list and minimum order quantity before launch if you want wholesale checkout to be automated.
